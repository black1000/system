package jp.co.f1.spring.uos.entity;

import java.util.Date;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "orderinfo")

public class Order {

	// 注文No(外部キー制約)

	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Id
	@Column(length = 20)
	private String orderno;

	public String getOrderno() {
		return orderno;

	}

	public void setOrderno(String orderno) {
		this.orderno = orderno;
	}

	// ユーザID(外部キー制約)
	@Column(length = 16)
	private String userid;

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}


// 注文の合計金額
	@Column(length = 20)
	private int totalprice;

	public int getTotalprice() {
		return totalprice;
	}

	public void setTotalprice(int totalprice) {
		this.totalprice = totalprice;
	}

	// 注文の合計個数
	@Column(length = 20)
	private int totalquantity;

	public int getTotalquantity() {
		return totalquantity;

	}

	public void setTotalquantity(int totalquantity) {
		this.totalquantity = totalquantity;
	}
 // 注文日時
	@Column(length = 20)
	private Date datetime;

	public Date getDatetime() {
		return datetime;

	}

	public void setDatetime(Date datetime) {
		this.datetime = datetime;
	}
	
	// 注文者名
	@Column(length = 100)
	private String name;
	
	public String getName() {
		return name;
		
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	// 注文者の住所
	@Column(length = 255)
	private String address;
	
	public String getAddress() {
		return address;
	}
	
	public void setAddress(String address) {
		this.address = address;
	}
	
	// 注文者のメールアドレス
	@Column(length = 100)
	private String email;
	
	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	// 備考
	@Column(length = 200)
	private String remarks;
	
	public String getRemarks() {
		return remarks;
	}
	
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
	// 入金状況
	@Column(length = 1)
	private String payment;
	
	public String getPayment() {
		return payment;
	}
	
	public void setPayment(String payment) {
		this.payment = payment;
		
	}
	
	// 発送状況
	@Column(length = 1)
	private String shipment;
	
	public String getShipment() {
		return shipment;
	}
	
	public void setShipment(String shipment) {
		this.shipment = shipment;
		
	}
	

	// OrderDetailオブジェクト
	@OneToMany
	@JoinColumn(
	    name = "orderno",
	    referencedColumnName = "orderno",
	    insertable = false,
	    updatable = false
	)
	private List<OrderDetail> orderdetails;

	public List<OrderDetail> getOrderdetails() {
	    return orderdetails;
	}

	public void setOrderdetails(List<OrderDetail> orderdetails) {
	    this.orderdetails = orderdetails;
	}
}
